package com.tienda.app.enums;

public enum Currency {
    USD,
    EUR
}
