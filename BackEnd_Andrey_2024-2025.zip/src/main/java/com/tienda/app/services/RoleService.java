package com.tienda.app.services;


import org.springframework.stereotype.Service;

@Service
public class RoleService {

}
