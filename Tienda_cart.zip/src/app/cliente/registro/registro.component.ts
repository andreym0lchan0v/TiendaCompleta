import { Component } from '@angular/core';

@Component({
  selector: 'app-registro',
  imports: [],
  standalone: true,
  templateUrl: './registro.component.html',
  styleUrl: './registro.component.scss'
})
export class RegistroComponent {

}
