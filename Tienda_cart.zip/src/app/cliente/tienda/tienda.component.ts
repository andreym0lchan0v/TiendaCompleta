import { Component } from '@angular/core';

@Component({
  selector: 'app-tienda',
  imports: [],
  standalone: true,
  templateUrl: './tienda.component.html',
  styleUrl: './tienda.component.scss'
})
export class TiendaComponent {

}
