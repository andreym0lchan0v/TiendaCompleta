import { Component } from '@angular/core';

@Component({
  selector: 'app-stats',
  imports: [],
  standalone: true,
  templateUrl: './stats.component.html',
  styleUrl: './stats.component.scss'
})
export class StatsComponent {

}
