import { Component } from '@angular/core';

@Component({
  selector: 'app-tab-grid',
  imports: [],
  templateUrl: './tab-grid.component.html',
  styleUrl: './tab-grid.component.scss'
})
export class TabGridComponent {

}
