export const environment = {
  production: true,
  apiUrl: 'https://api.google.com/api',
  tokenSecure: true
}
