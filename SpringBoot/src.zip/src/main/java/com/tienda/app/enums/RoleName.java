package com.tienda.app.enums;

public enum RoleName {
    CLIENT,
    ADMIN,
    SELLER,
}

